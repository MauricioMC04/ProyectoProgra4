/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;


import frames.ventanaLogin;

/**
 *
 * @author dannycolumna
 */
public class main {

    /**
     * @param args the command line arguments
     */
    
    public static ventanaLogin V;
    
    public static void main(String[] args) {
//        VSDC = new ventanaVendedor();
//        VSDC.setVisible(true);
//        VSDC.setExtendedState(MAXIMIZED_BOTH);
//        VSDC.setTitle("Sistema de Cafeteria");
//        System.err.println("Sistema de Cafeteria");
//        System.err.println("\nCreadores: \n- Danny A. Columna"
//                + "\n- Mauricio Mora"
//                + "\n- Erick Acuña");
        
        
//        VA = new ventanaAdministrador();
//        VA.setVisible(true);
     
        V = new ventanaLogin();
        V.setVisible(true);
    }
    
}

