/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import javax.swing.JOptionPane;

    

public class ListaVenta {
    
    private NodoVenta cabeza;
     
    public ListaVenta() {
        this.cabeza = null;
    }

    public NodoVenta getCabeza() {
        return cabeza;
    }

    public void setCabeza(NodoVenta cabeza) {
        this.cabeza = cabeza;
    }

    public int size() {
        int size = 0;
        NodoVenta Aux = this.getCabeza();
        while(Aux != null){
            size++;
            Aux = Aux.getSiguiente();
        }
        return size;
    }
    
    public boolean isEmpty(){
        boolean vacio = true; 
        if(this.size() == 0){
            vacio = true;
        }else{
            vacio = false;
        }
        return vacio;
    } 

    public void add(Bebida data) {
        if (this.isEmpty()) {
            NodoVenta nuevo = new NodoVenta(data);
            cabeza = nuevo;
        } else {
            NodoVenta nuevo = new NodoVenta(data);
            NodoVenta Aux = this.getCabeza();
            while(Aux.getSiguiente() != null){
                Aux = Aux.getSiguiente();
            }
            Aux.setSiguiente(nuevo);
        }
    }
    
    public Bebida get(int index) {
        if(!this.isEmpty()){
            if(index > this.size() || index < 0){
                throw new IndexOutOfBoundsException();
            }else{
                NodoVenta Aux = this.getCabeza();
                int cont = 0;
                while(cont != index && Aux.getSiguiente() != null){
                    cont ++;
                    Aux = Aux.getSiguiente();
                }
                return Aux.getBebida();
            }
        }else{
            JOptionPane.showMessageDialog(null, "Vacia");
            return null;
        }    
    }
    
    public void remove(int index) {
        if (index >= 0 && index <= this.size()-1) {
            if (0 == index) {
                this.setCabeza(this.getCabeza().getSiguiente());
            } else if (this.size()-1 == index) {
                int cont = 0;
                NodoVenta aux = this.getCabeza();
                while(cont < index-1) {
                    aux = aux.getSiguiente();
                    ++cont;
                }
                aux.setSiguiente(null);
            } else {
                int cont = 0;
                NodoVenta aux = this.getCabeza();
                while (cont < index -1) {
                    aux = aux.getSiguiente();
                    ++cont;
                }
                aux.setSiguiente(aux.getSiguiente().getSiguiente());
            }
        } else {
        }
    }
}
