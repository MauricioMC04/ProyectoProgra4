
package clases;

public class Venta {
    
}
